# ==========================================================================
# File: readme.txt (placeholder)
# ==========================================================================
=== SELLO ===
Contributors: sello
Tags: filters, facets, woo, acf, slider
Requires at least: 6.0
Tested up to: 6.6
Stable tag: 0.1.0
License: GPLv2 or later

Skeleton admin for SELLO (V1).
