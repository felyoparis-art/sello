// ==========================================================================
// File: assets/js/admin.js
// ==========================================================================
(function($){
  $(function(){
    // Placeholder admin ready
    // console.log('SELLO admin loaded');
  });
})(jQuery);
