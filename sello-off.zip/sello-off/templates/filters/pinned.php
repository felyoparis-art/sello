<?php
/** Pinned placeholder (V1) */
if (!defined('ABSPATH')) exit;
?>
<div class="sello-pinned-inner">
  <h4><?php esc_html_e('Pinned','sello');?></h4>
  <ul class="sello-pinned-list">
    <li><em><?php esc_html_e('Configure manual or dynamic items (V2).','sello');?></em></li>
  </ul>
</div>
