<?php
namespace Sello\Admin\ListTables; defined('ABSPATH') || exit;
class FiltersTable { /* using native edit.php?post_type=sello_filter */ }
