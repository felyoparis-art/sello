<?php
namespace Sello\Admin\ListTables; defined('ABSPATH') || exit;
class PresetsTable { /* using native edit.php?post_type=sello_preset */ }
